#include<stdio.h>
#include<stdlib.h>
void FIFO(char[],char[],int,int);
void Lru(char[],char[],int,int);
void opt(char[],char[],int,int);

int main()
{
	int ch,YN=1,i,l,f;
	char F[10],s[25];
	
	printf("\n\n\t Enter the number of empty frames:");
	scanf("%d",&f);
	
	printf("\n\n\t Enter the length of string:");	
	scanf("%d",&l);

	printf("\n\n\t Enter the string:");	
	scanf("%s",s);
	
	for(i=0;i<f;i++)
		F[i]=-1;
	
	do
	{
		printf("\n\n\t *********MENU*********");
		printf("\n\n\n\t1.FIFO\n\n2.IRU \n\n\t 4.EXIT");
		
		printf("Enter your choice:");
		scanf("%d",&ch);
	
		switch(ch)
		{
			case 1:for(i=0;i<f;i++)
				{
					F[i]=-1;
				}
				FIFO(s,F,l,f);
				break;
			
			case 2:for(i=0;i<f;i++)
				{
					F[i]=-1;
				}
				Lru(s,F,l,f);
				break;
			case 4:exit(0);
		}
	
		printf("\n\n\t Do you want to continue if YES press 1 \n\n\t if NO press 0:");
		scanf("%d",&YN);
	
	}while(YN==1); return(0);
}
void FIFO(char s[],char F[],int l,int f)
{

		int i,j=0,k,flag=0,cnt=0;
		printf("\n\t PAGE\t FRAMES \t FAULTS");
		
		for(i=0;i<l;i++)
		{
			for(k=0;k<f;k++)
			{
				if(F[k]==s[i])
					flag=1;
			}
			if(flag==0)
			{
				printf("\n\t%c\t",s[i]);
				F[j]=s[i];
				j++;
			
				for(k=0;k<f;k++)
				{
					printf("%c",F[k]);
				}
				printf("\t page_fault%d",cnt);
				cnt++;
			}
			else
			{
				flag=0;
				printf("\n\t%c\t",s[i]);
				for(k=0;k<f;k++)
				{
					printf("%c",F[k]);
				}
				printf("\t no page_fault");
			}
			if(j==f)
				j=0;
		}
}
void Lru(char s[],char F[],int l,int f)
{
		int i,j=0,k,m,flag=0,cnt=0,top=0;
		
		printf("\n\t PAGE \t FRAMES \t FAULTS");
		for(i=0;i<l;i++)
		{
			for(k=0;k<f;k++)
			{
				if(F[k]==s[i])
				{
					flag=1;
					break;
				}
			}
			printf("\n\t%c\t",s[i]);
			if(j!=f&&flag!=1)
			{
				F[top]=s[i];
				j++;
				if(j!=f)
					top++;
			}
			else
			{
				if(flag!=1)
				{
					for(k=0;k<top;k++)
					{
						F[k]=F[k+1];
					}
					F[top]=s[i];
				}
				if(flag==1)
				{
					for(m=k;m<top;m++)
					{
						F[m]=F[m+1];
					}
					F[top]=s[i];
				}
			}
			for(k=0;k<f;k++)
			{
				printf("%c",F[k]);
			}
			if(flag==0)
			{
				printf("\t page_fault%d",cnt);
				cnt++;
			}
			else
				printf("\t no page fault");
				flag=0;
		}
}
			
