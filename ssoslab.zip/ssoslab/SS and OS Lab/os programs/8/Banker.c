#include <stdio.h>
#include <stdlib.h>

/*
 * Data Wrapper : a structure to hold the data matrix (Why ? : To avoid Pointers)
 *
 * 1. available [i] : number(i) resource instances available  
 * 2. max [i][j] : max number of instances of resource(i), that process(j) can request at any given time
 * 3. allocation [i][j] : number of instances of resource(j) held by process (i)
 *
 */

struct DataWrapper
{
    int available[10];
    int max[10][10];
    int allocation[10][20];
};

/* 
 * Function Blueprints :
 * 1. getData() : to read data matrix from user
 * 2. evaluateSystem(params) : to evaluate system state (Banker's Safety Procedure Algorithm)
 * 3. getSystemState(params) : a wrapper for evaluateSystem(param)
 * 4. getResourceRequest(params) : to evaluate system state after new request (Banker's Resource Request Algorithm)
 * 
 */

void getData();
void evaluateSystem(int max[10][10], int allocation[10][20], int available[10]);
void getSystemState(struct DataWrapper data);
void getResourseRequest(struct DataWrapper data);

/* Global Variables :
 * p : number of process
 * r : number of resources
 * i,j : index variables
 * curProcess : current process indicator
 * count : a counting variable to track completed processes
 */
int p, r, i, j, curProcess, count = 0;

int main()
{
    // Create a DataWrapper type variable to store the data matrix
    struct DataWrapper data;

    // Read & Strore the data matrix
    printf("Enter number of process : ");
    scanf("%d", &p);
    printf("Enter the number of resource : ");
    scanf("%d", &r);
    printf("Enter maximum resource for each process :\n");
    for (i = 0; i < p; i++)
    {
        printf("For P%d : ", i);
        for (j = 0; j < r; j++)
            scanf("%d", &data.max[i][j]);
    }
    printf("Enter the allocation for each process : \n");
    for (i = 0; i < p; i++)
    {
        printf("For process %d : ", i);
        for (j = 0; j < r; j++)
            scanf("%d", &data.allocation[i][j]);
    }

    printf("Enter the available resource : ");
    for (i = 0; i < r; i++)
        scanf("%d", &data.available[i]);
    
    // Banker's Algorithm : Safety Procedure
    getSystemState(data);
    // Banker's Algorithm : ResourceRequest
    getResourseRequest(data);
    return 0;
}

void evaluateSystem(int max[10][10], int allocation[10][20], int available[10])
{
    int need[10][10], completed[10], safesequence[10];

    // Initialize completed & safesequence with 0 Array
    for (i = 0; i < p; i++){
        completed[i] = 0;
        safesequence[i]=0;
    }

    // Find Need matrix : Max Matrix - Allocation Matrix
    for (i = 0; i < p; i++)
        for (j = 0; j < r; j++)
            need[i][j] = max[i][j] - allocation[i][j];
    
    count = 0;
    do
    {
        //Display Data Matrix
        printf("\nProcess\tMaxim\tAlloc\tNeed\n");
        for (i = 0; i < p; i++)
        {
            printf("P%d", i);
            printf("\t");
            for (j = 0; j < r; j++)
                printf("%d", max[i][j]);
            printf("\t");
            for (j = 0; j < r; j++)
                printf("%d", allocation[i][j]);
            printf("\t");
            for (j = 0; j < r; j++)
                printf("%d", need[i][j]);
            printf("\n");
        }

        /*
         * Select which process to execute based on
         * resource availablity and process needs
         *
         */
        curProcess = -1;
        for (i = 0; i < p; i++) // Iterate though all processes
        {
            if (completed[i] == 0) // Check if process-i is not completed : 0 = not complete, 1 = complete
            {
                curProcess = i; // Mark i as curProcess
                for (j = 0; j < r; j++)
                {
                    /*
                     * Check if availablity of resources is less than the process needs.
                     * Dicard and move to next process, if needed resources are not available.
                     */
                    if (available[j] < need[i][j])
                    {
                        curProcess = -1;
                        break;
                    }
                }
            }
            if (curProcess != -1) //Check if process is completed : -1 = not completed, otherwise completed
                break;
        }

        //Check again if process is completed, to filter out non comleted processes from SafeSequence
        if (curProcess != -1)
        {
            printf("\nProcess %d executed\n", curProcess);
            safesequence[count] = curProcess; //Add Process to SafeSequence
            count++; //Increment count to move to next process
            for (j = 0; j < r; j++)
            {
                available[j] += allocation[curProcess][j]; // Update available resources
                allocation[curProcess][j] = 0; //De allocate resources from the process
                max[curProcess][j] = 0; // Set max to 0, to indicate no more work is required
                completed[curProcess] = 1; // Mark process as completed
            }
        }

        // Display Available Resources
        printf("\nAvailable :");
        for (i = 0; i < r; i++)
        {
            printf("%d ", available[i]);
        }
        printf("\n");
    } while (count != p && curProcess != -1);

    //Check if All Processes have executed & print Safe Sequence
    if (count == p)
    {
        printf("System is in safe state\n");
        printf("Safe sequence : ");
        for (i = 0; i < p; i++)
        {
            printf("(%d)", safesequence[i]);
            printf("->");
        }
        printf("\n\n");
    }
    else
    {
        printf("System is in unsafe state\n");
    }
}


void getSystemState(struct DataWrapper data)
{
    // Call System State Evaluation Algorithm
    evaluateSystem(data.max, data.allocation, data.available);
}


void getResourseRequest(struct DataWrapper data)
{
    int rp; // Requesting Process
    int newRequest[1][10]; // New Request
    int newNeed[1][20]; // New Need

    printf("Enter requesting process no. : ");
    scanf("%d", &rp);

    printf("Enter new request for P%d : ", rp);
    for (j = 0; j < r; j++)
    {
        scanf("%d", &newRequest[1][j]);
    }

    /*
     * Case 01 : if Request <= Need
     *              then GOTO Case 2
     *           else
     *              show Unsafe System & Quit
     */
    for (j = 0; j < r-1; j++)
    {
        // Find new Need & compare with new Request
        newNeed[1][j] = data.max[rp][j] - data.allocation[rp][j];
        if (newRequest[1][j] > newNeed[1][j])
        {
            printf("System is in unsafe state\n");
            exit(0);
        }
    }

    /*
     * Case 02 : if Request <= Available
     *              then GOTO Case 3
     *           else
     *              show Unsafe System & Quit
     */
    for (j = 0; j < r; j++)
    {
        if (newNeed[1][j] > data.available[j])
        {
            printf("System is in unsafe state\n");
            exit(0);
        }
    }

    /*
     * Case 03 :
     * Available = Available - Request
     * Allocation = Allocation + Request
     * Need = Need - Request
     *
     */
    for (j = 0; j < r; j++)
    {
        data.available[j] = data.available[j] - newRequest[1][j];
        data.allocation[rp][j] = data.allocation[rp][j] + newRequest[1][j];
    }

    // Call System State Evaluation Algorithm
    evaluateSystem(data.max, data.allocation, data.available);
}

