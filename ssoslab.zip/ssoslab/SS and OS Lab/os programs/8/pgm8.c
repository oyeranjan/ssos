#include<stdio.h>
#include<stdlib.h>

struct DataWrapper
{
	int available[10];
	int max[10][10];
	int allocation[10][20];
};

void getdata();
void evaluatesystem(int max[10][10],int allocation[10][20],int available[10]);
void getsystemstate(struct DataWrapper data);
void getresourcerequest(struct DataWrapper data);

int p,r,i,j,curprocess,count=0;

int main()
{
		struct DataWrapper data;
		printf("Enter number of process");
		scanf("%d",&p);

		printf("Enter the number of resource:");
		scanf("%d",&r);
	
		printf("Enter maximum resource for each process");
	
		for(i=0;i<p;i++)
		{
			printf("For P%d:",i);
		
			for(j=0;j<r;j++)
				scanf("%d",&data.max[i][j]);
		}
		printf("Enter the allocation for each process:\n");
	
		for(i=0;i<p;i++)
		{
			printf("For process%d:",i);
			for(j=0;j<r;j++)
				scanf("%d",&data.allocation[i][j]);
		}
		printf("Enter the available resource:");
		for(i=0;i<r;i++)
			scanf("%d",&data.available[i]);
	
		getsystemstate(data);
		getresourcerequest(data);
	
		return 0;
}
void evaluatesystem(int max[10][10],int allocation[10][20],int available[10])
{
	
		int need[10][10],completed[10],safesequence[10];

		for(i=0;i<p;i++)
		{
			completed[i]=0;
			safesequence[i]=0;
		}
		for(i=0;i<p;i++)
			for(j=0;j<r;j++)
		
				need[i][j]=max[i][j]-allocation[i][j];
		count=0;


		do
		{
			printf("\n process \t Maxim \t Alloc \t need \n");
			
			for(i=0;i<p;i++)
			{
				printf("P%d",i);
				printf("\t");
		
				for(j=0;j<r;j++)
					printf("%d",max[i][j]);
				printf("\t");

				for(j=0;j<r;j++)
					printf("%d",allocation[i][j]);
	
				printf("\t");
		
				for(j=0;j<r;j++)
					printf("%d",need[i][j]);
				printf("\n");
			
			}
		curprocess=-1;
		
		for(i=0;i<p;i++)
		{
			if(completed[i]==0)
			{
				curprocess=i;
				for(j=0;j<r;j++)
				{
					if(available[j]<need[i][j])
					{
						curprocess=-1;
						break;
					}
				}
			}			
			if(curprocess!=-1)
				break;
		}
		if(curprocess!=-1)
		{
			printf("\n process%d executed\n",curprocess);
			
			safesequence[count]=curprocess;
			count++;
		
			for(j=0;j<r;j++)
			{
				available[j]+=allocation[curprocess][j];
				completed[curprocess]=1;
			}
		}
		
		printf("\n available");
	
		for(i=0;i<r;i++)
		{
			printf("%d",available[i]);
		}
		printf("\n");
	}while(count!=p && curprocess!=-1);
	
	if(count==p)
	{
	
		printf("System is in safe state");
		
		printf("safe sequence:");
	
		for(i=0;i<p;i++)
		{
			printf("(%d)",safesequence[i]);
			printf("->");
		}
		printf("\n \n");
	}
	else
	{
		printf("System is in unsafe state\n");
	}
}

void getsystemstate(struct DataWrapper data)
{
	evaluatesystem(data.max,data.allocation,data.available);
}
void getresourcerequest(struct DataWrapper data)
{
		int rp;
		int newrequest[1][10];
		int newneed[1][20];
	
		printf("Enter requesting process number:");
		scanf("%d",&rp);
	
		printf("Enter new request for P%d",rp);

		for(j=0;j<r;j++)
		{
			scanf("%d",&newrequest[1][j]);
		}
		
		for(j=0;j<r;j++)
		{
			newneed[1][j]=data.max[rp][j]-data.allocation[rp][j];
	
			if(newrequest[1][j]>newneed[1][j])
			{
				printf("System is in unsafe state\n");
				exit(0);
			}
		}

		for(j=0;j<r;j++)
		{
			
	
			if(newrequest[1][j]>data.available[j])
			{
				printf("System is in unsafe state\n");
				exit(0);
			}
		}
	
		for(j=0;j<r;j++)
		{
			data.available[j]=data.available[j]-newrequest[1][j];
			data.allocation[rp][j]=data.allocation[rp][j]+newrequest[1][j];
		}
		evaluatesystem(data.max,data.allocation,data.available);
}
	
		



