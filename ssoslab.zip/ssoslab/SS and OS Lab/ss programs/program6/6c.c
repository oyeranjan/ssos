#include<stdio.h>
#include<conio.h>
void main()
{
int a=10,b=20;
printf("%d%d",a,b);
}

