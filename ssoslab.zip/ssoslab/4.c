#include<stdio.h>
#include<string.h>
int k=0,z=0,i=0,j=0,c=0,y=0;
char a[16],re[20],rt[20],rf[20],stk[15],act[10];
void check();
void main()
{
	puts("GRAMMAR is E->E+T|T,T->T*F|F,F->(E)|id");
	puts("enter input string:");
	gets(a);
	y=c=strlen(a);
	strcpy(act,"SHIFT->");
	puts("stack \t input \t action\n");
	for(k=0,i=0;j<c;k++,i++,j++)
	{
		if(a[j]=='i' && a[j+1]=='d')
		{
			stk[i]=a[j];
			stk[i+1]=a[j+1];
			stk[i+2]='\0';
			a[j]=' ';
			a[j+1]=' ';
			printf("\n$%s\t%s$\t%sid",stk,a,act);
			y=y-2;
			check();
		}
		else
		{
			stk[i]=a[j];
			stk[i+1]='\0';
			a[j]=' ';
			printf("\n$%s\t%s$\t%ssymbols",stk,a,act);
			y=y-1;
			check();
		}
	}
	
}
void check()
{
	strcpy(re,"REDUCE TO E");
	strcpy(rt,"REDUCE TO T");
	strcpy(rf,"REDUCE TO F");
	for(z=0;z<c;z++)
		if(stk[z]=='i' && stk[z+1]=='d')
		{
			stk[z]='F';
			stk[z+1]='\0';
			printf("\n$%s\t%s$\t%s",stk,a,rf);
			j++;
		}
	
	for(z=0;z<c;z++)
		if(stk[z]=='T' && stk[z+1]=='*' && stk[z+2]=='F')
		{
			stk[z]='T';
			stk[z+1]='\0';
			stk[z+2]='\0';
			printf("\n$%s\t%s$\t%s",stk,a,rt);
			i=i-2;
		}
	for(z=0;z<c;z++)
		if(stk[z]=='(' && stk[z+1]=='E' && stk[z+2]==')')
		{
			stk[z]='F';
			stk[z+1]='\0';
			stk[z+2]='\0';
			printf("\n$%s\t%s$\t%s",stk,a,rf);
			i=i-2;
		}
		
	for(z=0;z<c;z++)
		if(stk[z]=='F' && stk[z+1]=='\0')
		{
			stk[z]='T';
			printf("\n$%s\t%s$\t%s",stk,a,rt);
			
		}	
	for(z=0;z<c;z++)
		if(stk[z-1]=='\0' && stk[z]=='T' && stk[z+1]=='\0' && a[2]!='*')
		{
			stk[z]='E';
			stk[z+1]='\0';
			printf("\n$%s\t%s$\t%s",stk,a,re);
			
		}
	if(y==0)
	{
		for(z=0;z<c;z++)
			if(stk[z]=='E' && stk[z+1]=='+' && stk[z+2]=='T')
			{
				stk[z]='E';
				stk[z+1]='\0';
				stk[z+2]='\0';
				printf("\n$%s\t%s$\t%s",stk,a,re);
				i=i-2;
			}
	}
}	



