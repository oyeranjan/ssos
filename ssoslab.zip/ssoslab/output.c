int main()
{

int a,b,c;
a=10;
b=12;
c=a+b;

return c;
}
